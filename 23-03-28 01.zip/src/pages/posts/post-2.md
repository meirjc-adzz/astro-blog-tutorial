---
title: My Second Blog Post
author: Astro Learner
description: "After learning some Astro, I couldn't stop!"
image:
  url: "https://astro.build/assets/blog/astro-showcase/astro-showcase-screenshot.jpg"
  alt: "Thumbnails of websites from the Astro Showcase site."
pubDate: 2022-07-08
tags: ["astro", "blogging", "learning in public", "successes"]
---

After a successful first week learning Astro, I decided to try some more. I wrote and imported a small component from memory!
